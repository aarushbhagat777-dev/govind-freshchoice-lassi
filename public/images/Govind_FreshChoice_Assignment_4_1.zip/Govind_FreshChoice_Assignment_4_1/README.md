# Govind FreshChoice Sweet Rose Lassi — Assignment 4.1

This is a Vercel-ready Next.js starter project for the proposed 200 ml concept.

## Important academic / accuracy note
The product, recipe, pack size, ₹30 indicative price and nutrition figures are proposed student-concept assumptions, not verified commercial product specifications. Nutrition is estimated per 100 ml and must be checked by a qualified food technologist/lab before any real sale. Do not use invented FSSAI licence numbers, barcodes, dates, manufacturer claims, ratings, delivery times or certifications. The image mockups are visual concepts; replace any tiny/inaccurate generated label text with verified artwork before submission or real-world use.

## Run locally
1. Install Node.js (18+).
2. In this folder run `npm install`.
3. Run `npm run dev` and open http://localhost:3000.

## Publish
1. Create/sign in to a Vercel account.
2. Import this project folder/repository into Vercel.
3. Deploy. Copy the published `vercel.app` URL for submission.
4. Check the live page on mobile and desktop before submitting.

## Platform
The design is Blinkit-inspired for the assignment only. Your mentor has not confirmed Blinkit vs Zepto; change the visual styling if they assign Zepto.
