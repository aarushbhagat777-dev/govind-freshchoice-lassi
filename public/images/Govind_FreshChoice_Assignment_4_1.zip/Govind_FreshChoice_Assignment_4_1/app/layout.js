export const metadata = {
  title: "Govind FreshChoice Sweet Rose Lassi",
  description: "Proposed 200 ml sweet rose lassi product concept.",
};
export default function RootLayout({ children }) {
  return <html lang="en"><body>{children}</body></html>;
}
