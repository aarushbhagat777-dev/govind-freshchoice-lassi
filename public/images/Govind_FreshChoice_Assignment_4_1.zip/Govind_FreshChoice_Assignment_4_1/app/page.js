"use client";
import { useState } from "react";
import Image from "next/image";
import "./styles.css";

const images = [
  { src: "/images/front-pack.png", label: "Front of pack" },
  { src: "/images/back-pack.png", label: "Back of pack" },
  { src: "/images/ingredients-panel.png", label: "Ingredients panel" },
];
const nutrition = [
  ["Energy", "62 kcal"], ["Protein", "3.0 g"], ["Carbohydrate", "7.5 g"],
  ["Total sugars", "6.5 g"], ["Total fat", "2.5 g"], ["Calcium", "110 mg"],
];

export default function Home() {
  const [active, setActive] = useState(0);
  const [cart, setCart] = useState(0);
  return <main>
    <header className="topbar">
      <div className="brandmark">blink<span>it</span></div>
      <div className="location">⌖ Deliver to <b>Your location</b></div>
      <div className="search">⌕　Search for lassi, milk and more</div>
      <button className="cart" onClick={() => setCart(cart + 1)}>🛒 Cart ({cart})</button>
    </header>
    <nav className="crumb">Home　›　Dairy & Breakfast　›　Lassi & Buttermilk　›　Sweet Rose Lassi</nav>
    <section className="product">
      <aside className="thumbs">
        {images.map((im, i) => <button key={im.src} className={active === i ? "thumb selected" : "thumb"} onClick={() => setActive(i)} aria-label={im.label}>
          <Image src={im.src} alt={im.label} width={76} height={84} />
        </button>)}
      </aside>
      <div className="hero">
        <div className="heroImage"><Image src={images[active].src} alt={images[active].label} fill priority style={{objectFit:"contain"}} /></div>
        <div className="dots">{images.map((x,i)=><button key={x.src} onClick={()=>setActive(i)} className={active===i?"dot active":"dot"} aria-label={`View ${x.label}`} />)}</div>
      </div>
      <section className="details">
        <div className="eyebrow">GOVIND MILK · FRESHCHOICE</div>
        <h1>Govind FreshChoice Sweet Rose Lassi</h1>
        <p className="size">200 ml · Single-serve bottle</p>
        <div className="price">₹30 <span className="concept">Indicative concept price</span></div>
        <div className="note">Proposed product concept for academic assignment</div>
        <p className="desc">A creamy, refreshing sweet lassi concept with a delicate rose flavour. Designed to be served chilled, with clear flavour and freshness information on pack.</p>
        <ul className="highlights"><li>Sweet rose flavour</li><li>Serve chilled</li><li>Milk-based beverage</li></ul>
        <button className="add" onClick={() => setCart(cart + 1)}>＋ Add to cart</button>
        <p className="small">Demo page only — no real ordering or delivery service is connected.</p>
      </section>
      <aside className="info">
        <h2>About this item</h2>
        <p>Govind FreshChoice Sweet Rose Lassi is a proposed single-serve dairy beverage concept. Shake well and serve chilled.</p>
        <h2>Ingredients</h2>
        <p>Proposed formulation: toned milk, sugar, rose flavouring, stabiliser and permitted food colour, if required. Final ingredient declaration must follow the validated recipe and applicable regulations.</p>
        <h2>Allergen information</h2><p>Contains milk.</p>
        <h2>Nutrition information</h2><p className="small">Estimated values per 100 ml — for concept illustration only.</p>
        <table><tbody>{nutrition.map(([a,b])=><tr key={a}><td>{a}</td><td>{b}</td></tr>)}</tbody></table>
      </aside>
    </section>
    <section className="lower">
      <h2>Product details</h2>
      <p><b>Brand:</b> Govind Milk / FreshChoice</p>
      <p><b>Product:</b> Sweet Rose Lassi</p>
      <p><b>Net quantity:</b> 200 ml (proposed)</p>
      <p><b>Storage concept:</b> Keep refrigerated and serve chilled. Final storage conditions and shelf life require validation.</p>
      <p><b>Best before:</b> To be printed after shelf-life testing; no date is assigned in this concept.</p>
    </section>
    <footer>Student concept page · Blinkit-inspired layout · Not an official Blinkit listing · Product, formulation, price and nutrition are proposed/estimated and require verification.</footer>
  </main>;
}
